# Make sure you list all the project template files here in the manifest.
stylesheet 'screen.sass', :media => 'screen, projection'

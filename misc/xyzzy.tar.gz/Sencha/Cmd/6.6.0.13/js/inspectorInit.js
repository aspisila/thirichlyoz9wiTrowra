/*
 * Copyright (c) 2012-2015. Sencha Inc.
 */

SenchaInspector.init(Ext.manifest.inspector.address); 